You can get the trained model file from http://dlib.net/files, click on shape_predictor_68_face_landmarks.dat.bz2. 

The model dat file has to be in the ./model folder of the project.